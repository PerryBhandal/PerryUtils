module PillsHelper
end
