module ExercisesHelper
end
