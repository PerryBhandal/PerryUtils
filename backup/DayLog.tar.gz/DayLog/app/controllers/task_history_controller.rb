class TaskHistoryController < ApplicationController
  def index
    @title = "Task History"
  end


end
