$( document ).ready(function() {
  $( "#toggle_add_form" ).click(function() {
    $( "#add_form" ).toggle();
  });
});
