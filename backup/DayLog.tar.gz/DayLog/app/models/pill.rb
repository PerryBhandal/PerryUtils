class Pill < ActiveRecord::Base
end
