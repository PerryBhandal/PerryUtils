class Meal < ActiveRecord::Base
end
