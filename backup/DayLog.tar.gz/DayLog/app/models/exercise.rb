class Exercise < ActiveRecord::Base
end
