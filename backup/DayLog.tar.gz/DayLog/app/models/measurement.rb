class Measurement < ActiveRecord::Base
end
