class NoteCategory < ActiveRecord::Base
end
