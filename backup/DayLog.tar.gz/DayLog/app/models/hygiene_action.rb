class HygieneAction < ActiveRecord::Base
end
