class PremadeTask < ActiveRecord::Base
end
