rake assets:precompile
