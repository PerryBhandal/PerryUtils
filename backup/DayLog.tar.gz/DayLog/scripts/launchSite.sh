cd ..
screen -dmS dayLogSite rails server -e production
