./backupDatabase.sh
rake db:migrate RAILS_ENV="production"
